Archive extraction test.
